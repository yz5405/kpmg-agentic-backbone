import unittest
from fastapi.testclient import TestClient
from app.main import app


class DemoTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_pages_and_health(self):
        for path in ('/', '/explorer'):
            result = self.client.get(path)
            self.assertEqual(result.status_code, 200)
            self.assertIn('DEMO MODE', result.text)
        self.assertEqual(self.client.get('/health').json()['status'], 'ok')

    def test_rag_and_trace(self):
        result = self.client.post('/query', json={'query': 'What was Microsoft revenue for Q3 FY2026?', 'trace_id': 'test-rag'}).json()
        self.assertEqual(result['status'], 'SUCCESS', result)
        self.assertEqual(result['answer_mode'], 'extractive')
        self.assertTrue(result['citations'])
        self.assertTrue(all(r['metadata']['trace_id'] == 'test-rag' for r in result['evidence']))

    def test_graph_and_combined(self):
        for strategy in ('routed', 'combined'):
            result = self.client.post('/query', json={'query': 'Which subsidiaries did Microsoft acquire in 2026?', 'strategy': strategy}).json()
            self.assertEqual(result['status'], 'SUCCESS', result)
            self.assertIn('graph_search', result['plan']['tools'])

    def test_guardrails(self):
        self.assertEqual(self.client.post('/query', json={'query': 'hello'}).json()['status'], 'OFF_TOPIC')
        self.assertEqual(self.client.post('/query', json={'query': 'What was revenue in 2026?'}).json()['status'], 'CLARIFY')
        self.assertEqual(self.client.post('/query', json={'query': 'What was Apple revenue for Q3 FY2026?'}).json()['status'], 'NO_EVIDENCE')
        for payload in ({'query': ' '}, {'query': 'revenue', 'top_k': True}, {'query': 'revenue', 'top_k': 51}):
            self.assertEqual(self.client.post('/query', json=payload).status_code, 422)


if __name__ == '__main__':
    unittest.main()
